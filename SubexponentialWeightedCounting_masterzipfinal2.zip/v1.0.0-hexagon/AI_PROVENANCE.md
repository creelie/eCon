# AI provenance — Subexponential Weighted Counting and Exact Optimisation

Version 1.0.0, 27 October 2026. Sole author: Deep Bhattacharjee. Text classification: a mix of human-written and AI-generated.

Claude / Claude Code (Anthropic) assisted the drafting of the text, the exact-arithmetic check program of Appendix A (`anc/check_interpolation.py`, Python standard library, rational arithmetic only) and the three figures. The mathematical input is the summation routine of OpenAI's preprint "The Exponential Time Hypothesis is False" (25 October 2026), which Sections 3 and 4 reproduce with credit; the deductions of Sections 5 to 7 are proved in the paper by hand, and no statement of the paper rests on the check program. The author reviewed the text and takes responsibility for it.

AI systems are not authors. The package does not contain prompts or hidden reasoning traces.

Archive: release v1.0.0 of https://github.com/creelie/eCon , DOI https://doi.org/10.5281/zenodo.23695836.
