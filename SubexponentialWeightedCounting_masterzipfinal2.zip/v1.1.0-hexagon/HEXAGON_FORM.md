# Hexagon submission fields — v1.1.0

## Title

Subexponential Weighted Counting and Exact Optimisation

## Abstract

The deterministic algorithm of OpenAI that counts the satisfying assignments of a k-CNF in time 2^{o(n)} is reproduced in full and extended from counting to sums of local weights with values in any commutative Q-algebra. The extension gives deterministic 2^{o(n)} algorithms for exact Max-Cut and Max-k-SAT on sparse instances, for the independence polynomial and the maximum independent set of every graph, for Vertex Cover in time 2^{o(k)} + poly(n), for the density of states of Ising and Potts models on bounded-degree graphs, for the Tutte polynomial on the hyperbolas (x-1)(y-1) = q, for the minimum distance and the maximum-likelihood decoding of codes with sparse parity checks, for Max-Cut at average degree up to sqrt(log n)/(log log n)^3, and for every problem in SNP.

## Classification

Primary subject: cs.CC. Cross-list: cs.DS, math.CO.
MSC2020: Primary 68Q25; secondary 68Q17, 68W40, 05C31, 05C85, 82B20.
Tags: exponential time hypothesis, weighted counting, independence polynomial, vertex cover, Max-SAT, partition functions, Tutte polynomial, LDPC codes.
New submission (no earlier Hexagon record; version 1.1.0 of the paper, which supersedes the unsubmitted v1.0.0 package). arXiv identifier: leave blank.

## Contributor

Deep Bhattacharjee, ORCID 0000-0003-0466-750X.
Former affiliations: Electro-Gravitational Space Propulsion Laboratory (EGSPL), Bhubaneswar, Odisha 751030, India; University of Calcutta (Heramba Chandra College), Kolkata 700029, India.
Correspondence: d.bhattacharjee@erl-forschung.de (second address itsdeep@live.com).
No AI system is listed as a contributor.

## Text and human understanding

Text: A mix of human-written and AI-generated.
Human understanding: author selection.

## Provenance and tools

AI provenance upload: AI_PROVENANCE.md (in this folder, outside the source ZIP).
Tools: Anthropic Claude / Claude Code, Python (exact rational arithmetic), matplotlib for the figures, LaTeX / pdfLaTeX.

## Files and licence

PDF: SubexponentialWeightedCounting_final2.pdf (41 pages).
Source ZIP: SubexponentialWeightedCounting_final2-tex.zip; main document main.tex (pdfLaTeX, three passes, inline bibliography, no BibTeX); contains only main.tex, the section files, figures/ (4 PDF figures) and anc/ (check_interpolation.py). Compiles with `pdflatex -jobname=output main.tex`.
arXiv tarball: SubexponentialWeightedCounting_final2-arxiv.tar.gz (for arXiv only; not for Hexagon).
Manuscript licence: CC BY 4.0.

## Archive

Repository: https://github.com/creelie/eCon , release v1.1.0: https://github.com/creelie/eCon/releases/tag/v1.1.0 .
Version DOI: https://doi.org/10.5281/zenodo.23697614 . Concept DOI (all versions): https://doi.org/10.5281/zenodo.23695835 .

Funding: none. Competing interests: none.
Upload order: SubexponentialWeightedCounting_final2.pdf, SubexponentialWeightedCounting_final2-tex.zip, AI_PROVENANCE.md, HEXAGON_FORM.md.
