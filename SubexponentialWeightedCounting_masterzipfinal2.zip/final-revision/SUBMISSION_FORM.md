# Submission form — Subexponential Weighted Counting and Exact Optimisation, v1.0.0

**Title.** Subexponential Weighted Counting and Exact Optimisation

**Running head.** Subexponential weighted counting

**Author.** Deep Bhattacharjee (sole and corresponding author)
Formerly, Electro-Gravitational Space Propulsion Laboratory (EGSPL), Bhubaneswar, Odisha 751030, India
Formerly, University of Calcutta (Heramba Chandra College), 23/49 Gariahat Road, Golpark, Kolkata 700029, West Bengal, India
Emails: d.bhattacharjee@erl-forschung.de (corresponding), itsdeep@live.com, egspl@proton.me. ORCID 0000-0003-0466-750X.

**Article type.** Research article. Document class amsart, single column, pdfLaTeX, 31 pages, 3 figures (PNG in the repository, PDF in the source), no tables.

**Abstract.**
The deterministic algorithm of OpenAI that counts the satisfying assignments of a k-CNF in time 2^{o(n)} is reproduced in full and extended from counting to sums of local weights with values in any commutative Q-algebra. The extension gives deterministic 2^{o(n)} algorithms for exact Max-Cut and Max-k-SAT on sparse instances, for the independence polynomial and the maximum independent set of every graph, for Vertex Cover in time 2^{o(k)} + poly(n), for the density of states of Ising and Potts models on bounded-degree graphs, and for every problem in SNP.

**MSC 2020.** Primary 68Q25; Secondary 68Q17, 68W40, 05C31, 05C85, 82B20.

**Keywords.** exponential time hypothesis; weighted counting; independence polynomial; vertex cover.

**What the paper proves.** Starting from the summation routine of OpenAI's preprint "The Exponential Time Hypothesis is False" (25 October 2026), reproduced in full in Sections 3 and 4 with credit, the paper proves that every step of the routine is linear over the coefficient ring and runs it over truncated polynomial rings and group algebras (Theorem 5.3). Consequences, each with a complete proof: the whole weight profile of a sparse weighted constraint system, hence Max-k-SAT, Min-k-SAT and the number of optimal assignments (Theorem 6.1, Corollary 6.2); satisfying assignments of each Hamming weight (Corollary 6.3); Max-Cut and bisections of sparse graphs (Corollary 6.4); the weighted independence polynomial of every graph, with exponent n(log log n)^2/(log n)^{1/4} (Theorem 6.7, Corollary 6.8); Vertex Cover in time 2^{o(k)} + poly(n) (Theorem 6.11); finite domains, partition functions and homomorphism counts on bounded-degree graphs (Theorem 6.13, Corollary 6.14); Ising and Potts densities of states (Theorem 6.16); dominating sets, matchings, hitting sets, set splitting (Theorem 6.18); sparse permanents (Theorem 6.19); counting under a congruence (Proposition 6.21); k-SAT in SE and SNP contained in SE (Theorems 7.2, 7.4). Section 8 states what is not proved: dense objectives, the quadratic-time problems of fine-grained complexity, P versus NP.

**Declarations.** Funding: none. Conflicts of interest: none. Ethics approval: not applicable. The paper carries a declaration on the use of generative AI (Claude, for the check program of Appendix A and drafting).

**Data and code availability.** Repository https://github.com/creelie/eCon (branch main, release tag v1.0.0). Zenodo version DOI 10.5281/zenodo.23695836 (concept DOI 10.5281/zenodo.23695835), recorded in the paper, README.md and CITATION.cff. Programs: code/check_interpolation.py (exact arithmetic, 4 checks, about ten minutes), recorded output code/check_output.txt.

**Files in this folder.**
- SubexponentialWeightedCounting_final2.pdf — the compiled paper (31 pages).
- SubexponentialWeightedCounting_final2-tex.zip — main.tex, the section files, figures/ (PDF only), anc/ (the check program); compiles with `pdflatex -jobname=output main.tex` (three passes), 0 errors, 0 overfull boxes, no undefined references.
- SubexponentialWeightedCounting_final2-arxiv.tar.gz — the same source without anc/, flat, for arXiv.
- SUBMISSION_FORM.md — this form.
