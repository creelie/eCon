# Submission form — Subexponential Weighted Counting and Exact Optimisation, v1.2.0

**Title.** Subexponential Weighted Counting and Exact Optimisation

**Running head.** Subexponential weighted counting

**Author.** Deep Bhattacharjee (sole and corresponding author)
Formerly, Electro-Gravitational Space Propulsion Laboratory (EGSPL), Bhubaneswar, Odisha 751030, India
Formerly, University of Calcutta (Heramba Chandra College), 23/49 Gariahat Road, Golpark, Kolkata 700029, West Bengal, India
Emails: d.bhattacharjee@erl-forschung.de (corresponding), itsdeep@live.com, egspl@proton.me. ORCID 0000-0003-0466-750X.

**Article type.** Research article. Document class amsart, single column, pdfLaTeX, 45 pages, 4 figures (PNG in the repository, PDF in the source), no tables.

**Abstract.**
The deterministic algorithm of OpenAI that counts the satisfying assignments of a k-CNF in time 2^{o(n)} is reproduced in full and extended from counting to sums of local weights with values in any commutative Q-algebra. The extension gives deterministic 2^{o(n)} algorithms for exact Max-Cut and Max-k-SAT on sparse instances, for the independence polynomial, the maximum independent set and the knapsack problem with a conflict graph on every graph, for 0-1 integer programs whose rows involve boundedly many variables, for Vertex Cover in time 2^{o(k)} + poly(n), for the density of states of Ising and Potts models on bounded-degree graphs, for the Tutte polynomial on the hyperbolas (x-1)(y-1) = q, for the minimum distance and the maximum-likelihood decoding of codes with sparse parity checks, for Max-Cut and Max-k-SAT at average degree up to sqrt(log n)/(log log n)^3, and for every problem in SNP.

**MSC 2020.** Primary 68Q25; Secondary 68Q17, 68W40, 05C31, 05C85, 82B20.

**Keywords.** exponential time hypothesis; weighted counting; independence polynomial; vertex cover.

**What the paper proves.** Starting from the summation routine of OpenAI's preprint "The Exponential Time Hypothesis is False" (25 October 2026), reproduced in full in Sections 3 and 4 with credit, so that no statement depends on a text outside the paper, the paper proves that every step of the routine is linear over the coefficient ring and runs it over truncated polynomial rings and group algebras (Theorem 5.3). Consequences, each with a complete proof: the whole weight profile of a sparse weighted constraint system, hence Max-k-SAT, Min-k-SAT and the number of optimal assignments (Theorem 6.1, Corollary 6.2); satisfying assignments of each Hamming weight (Corollary 6.3); Max-Cut and bisections of sparse graphs (Corollary 6.4); the weighted independence polynomial of every graph, with exponent n(log log n)^2/(log n)^{1/4} (Theorem 6.7, Corollary 6.8); independent sets of every graph under a fixed number of weight budgets, hence the knapsack problem with an arbitrary conflict graph (Theorem 6.10, Corollary 6.11); Vertex Cover in time 2^{o(k)} + poly(n) (Theorem 6.13); finite domains, partition functions and homomorphism counts on bounded-degree graphs (Theorem 6.15, Corollary 6.16); Ising and Potts densities of states (Theorem 6.18); dominating sets, matchings, hitting sets, set splitting (Theorem 6.20); sparse permanents (Theorem 6.21); counting under a congruence (Proposition 6.23). Section 7 adds: several linear statistics at once (Theorem 7.1, Corollary 7.2); Max-k-Lin mod p, Max-q-Cut and balanced q-partitions (Theorem 7.3, Corollary 7.4); f-factors, Eulerian orientations, proper edge colourings and nowhere-zero flows on bounded-degree graphs (Theorem 7.5), hafnians (Corollary 7.6); the Tutte polynomial on every hyperbola (x-1)(y-1) = q with q a positive integer, including the chromatic and flow polynomials at q and the Potts partition function (Lemmas 7.8, 7.9, Theorem 7.10); weight enumerator, minimum distance and maximum-likelihood decoding of codes with sparse parity checks (Theorem 7.12); hypergraph matchings, exact covers, transversals and colourings (Theorem 7.14); output profiles of linear-size circuits (Theorem 7.15); 0-1 and bounded integer programs with O(n) rows of boundedly many variables, including exact cover with bounded element frequency and the partially ordered knapsack problem (Theorem 7.17, Corollary 7.18); growing density, with Max-Cut, Ising ground states, Max-k-SAT and sparse integer programs at average degree up to sqrt(log n)/(log log n)^3 (Theorem 7.19, Corollaries 7.20, 7.21). Section 8: k-SAT in SE and SNP contained in SE (Theorems 8.2, 8.4). Section 9 states what is not proved: Max-Cut with Theta(n^2) edges, the chromatic and Tutte polynomials as polynomials in q, the quadratic-time problems of fine-grained complexity, P versus NP.

**Declarations.** Funding: none. Conflicts of interest: none. Ethics approval: not applicable. The paper carries a declaration on the use of generative AI (Claude, for the check program of Appendix A and drafting).

**Data and code availability.** Repository https://github.com/creelie/eCon (branch main, release tag v1.2.0). Zenodo version DOI 10.5281/zenodo.23698450 (concept DOI 10.5281/zenodo.23695835), recorded in the paper, README.md and CITATION.cff. Programs: code/check_interpolation.py (exact arithmetic, 7 checks, about twenty minutes), recorded output code/check_output.txt.

**Files in this folder.**
- SubexponentialWeightedCounting_final2.pdf — the compiled paper (45 pages).
- SubexponentialWeightedCounting_final2-tex.zip — main.tex, the section files, figures/ (PDF only), anc/ (the check program); compiles with `pdflatex -jobname=output main.tex` (three passes), 0 errors, 0 overfull or underfull boxes, no undefined references.
- SubexponentialWeightedCounting_final2-arxiv.tar.gz — the same source without anc/, flat, for arXiv.
- SUBMISSION_FORM.md — this form.
